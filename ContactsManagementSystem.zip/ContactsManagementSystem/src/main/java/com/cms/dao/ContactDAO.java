package com.cms.dao;

import java.util.List;

import com.cms.entities.Contact;

/**
 * Declaration of DAO operations 
 * @author Vaibhav Kulkarni
 *
 */
public interface ContactDAO {
	
	public void saveOrUpdate(Contact contact);
	
	public void delete(int contactId);
	
	public Contact get(int contactId);
	
	public List<Contact> list();
	
	public List<Contact> listPageWise(int offset,int numbersPerPage);
}
