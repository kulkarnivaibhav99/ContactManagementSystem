package com.cms.entities;

public class Contact {
	private int id;
	private String name;
	private String email;
	private String surname;
	private String telephone;

	public Contact() {
	}

	public Contact(String name, String email, String surname, String telephone) {
		this.name = name;
		this.email = email;
		this.surname = surname;
		this.telephone = telephone;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getSurname() {
		return surname;
	}

	public void setSurname(String surname) {
		this.surname = surname;
	}

}
