package com.cms.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.cms.dao.ContactDAO;
import com.cms.entities.Contact;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * 
 * This controller class invokes appropriate handler methods
 * 
 * @author Vaibhav Kulkarni
 *
 */
@Controller
public class HomeController {
	int page = 1;
	int recordsPerPage = 5;

	@Autowired
	private ContactDAO contactDAO;

	@RequestMapping(value = "/")
	public ModelAndView listContact(ModelAndView model) throws IOException {
		List<Contact> listContact = contactDAO.list();
		model.addObject("listContact", listContact);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/{page}")
	public ModelAndView listContactPag(ModelAndView model, @PathVariable("page") int page) throws IOException {
		List<Contact> listContact = contactDAO.listPageWise((page - 1) * recordsPerPage, recordsPerPage);
		int noOfRecords = listContact.size();
		List<Contact> entirelist = contactDAO.list();
		int totalRec = entirelist.size();
		int noOfPages = (int) Math.ceil(totalRec * 1.0 / recordsPerPage);

		model.addObject("noOfPages", noOfPages);
		model.addObject("currentPage", page);
		model.addObject("listContact", listContact);
		model.setViewName("home");
		return model;
	}

	@RequestMapping(value = "/newContact", method = RequestMethod.GET)
	public ModelAndView newContact(ModelAndView model) {
		Contact newContact = new Contact();
		model.addObject("contact", newContact);
		model.setViewName("addEditContact");
		return model;
	}

	@RequestMapping(value = "/saveContact", method = RequestMethod.POST)
	public ModelAndView saveContact(@ModelAttribute Contact contact) {
		contactDAO.saveOrUpdate(contact);
		return new ModelAndView("redirect:/1");
	}

	@RequestMapping(value = "/deleteContact", method = RequestMethod.GET)
	public ModelAndView deleteContact(HttpServletRequest request) {
		int contactId = Integer.parseInt(request.getParameter("id"));
		contactDAO.delete(contactId);
		return new ModelAndView("redirect:/1");
	}

	@RequestMapping(value = "/editContact", method = RequestMethod.GET)
	public ModelAndView editContact(HttpServletRequest request) {
		int contactId = Integer.parseInt(request.getParameter("id"));
		Contact contact = contactDAO.get(contactId);
		ModelAndView model = new ModelAndView("addEditContact");
		model.addObject("contact", contact);

		return model;
	}
}
